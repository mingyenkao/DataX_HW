test = {   'name': 'public_test_1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> test_accuracy > 0.85\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
