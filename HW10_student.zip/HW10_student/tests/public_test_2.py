test = {   'name': 'public_test_2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> test_accuracy > 0.86\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
