test = {   'name': 'public_test_4',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> test_accuracy > 0.88\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
