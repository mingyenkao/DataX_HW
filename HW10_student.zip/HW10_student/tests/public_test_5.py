test = {   'name': 'public_test_5',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> test_accuracy > 0.89\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
