test = {   'name': 'q1b',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> df_SP500.shape\n(1114, 2)',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
