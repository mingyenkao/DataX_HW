test = {   'name': 'q1c',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> df_30YTB['Date'][8]\n"
                                               "Timestamp('1977-09-01 "
                                               "00:00:00')",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
