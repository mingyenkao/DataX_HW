test = {   'name': 'q2a',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> None\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
