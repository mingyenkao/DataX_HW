test = {   'name': 'q2b',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> error<200000\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
