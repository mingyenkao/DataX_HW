test = {   'name': 'q2e',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> None\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
