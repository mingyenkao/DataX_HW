test = {   'name': 'q1d',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> len(cols) == 7\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> list(df0.index) == '
                                               "['Debate char length', "
                                               "'war_count', 'most_common_w', "
                                               "'most_common_w_count']\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               'df0.isnull().count().count() '
                                               '== 7\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
