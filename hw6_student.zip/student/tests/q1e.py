test = {   'name': 'q1e',
    'points': 4,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               "df0.describe().loc['count'].sum() "
                                               '>= 25\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               "df0.loc['most_common_w_count'].sum() "
                                               '>= 5000\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               "df0.loc['most_common_w_count'].max() "
                                               '>= 800\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> df0.loc['Debate char "
                                               "length'].max() >= 95000\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
