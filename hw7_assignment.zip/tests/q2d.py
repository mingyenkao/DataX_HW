test = {   'name': 'q2d',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> len(list(df.index)) >= 7\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
