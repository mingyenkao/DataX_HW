test = {   'name': 'q1c',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> len(urls) == 7\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
